def phone():
    mobile_number = 0
    try:
        mobile_number = int(input("Enter your mobile number: "))
        if len(str(mobile_number)) == 10:
            return mobile_number
        else:
            print("Mobile number entered not 10 digits long")
            phone()
    except:
        print("Invalid mobile number entered")
        phone()