'''MANALI'S CODE STARTS'''
#First message to user is the title of the project
print("WELCOME TO THE GROCERY STORE!")

#Dictionary holding userIDs of people as keys(UNIQUE), numbers as values
users = {'benny_27' : 9890708265}

#Importing a module carrying a function that ensures the entered mobile number is valid
import dotpy_ph

#Message that will appear after login. We'll update this function later.
def logged(x):
  print("Login successful! Hi,",x,"!")

#LOGIN function| argument people will be a dictionary with all users
def login(people):
  print("\nLOGIN Portal Active")
  mobile = dotpy_ph.phone()
  #we will use the following variable to proceed to shopping
  global start
  #We now check if the number is already signed up
  for i in people.keys():
    if people[i] == mobile:
      name = i
      logged(name)
      start = 1
      absent = 0
    else:
      start = 0
      absent = 1  
  if absent == 1:
    signup()
'''The variable absent had to be defined because when the signup function
  was called after else statement above, the dictionary that was 
  being iterated through, got updated with a new user. This gave us
  an error'''   

#SIGNUP function
def signup():
  global users
  print("\nSIGNUP Portal Active")
  name = input("Enter a userID: ")
  #ensuring each user gets a unique ID
  for i in users.keys():
    if i == name:
      while i == name:
        name = input("This user already exists. Enter a different ID : ")
  mobile = dotpy_ph.phone()
  #Creating a temporary dictionary| key = userID, value = mobile number  
  U = {name : mobile}
  #Updating the initial dictionary users with the new user's information
  users.update(U)
  print("Signup successful. Proceed to Login.")
  #calling the LOGIN function|argument = updated users dictionary
  login(users)
'''MANALI'S CODE ENDS'''

'''TARIKA'S CODE STARTS'''
# [[item code,item name, price,quantity],[item code, quantity, price,]]
Fruits_vegetables = [
   [0, "Mango(1kg)", 108], 
   [1, "Apple(1kg)", 150], 
   [2, "Banana(1kg)", 100],
   [3, "Orange(1kg)", 95], 
   [4, "Coconut(1pc)", 34], 
   [5, "Onions(1kg)", 29],
   [6, "Potatoes(1kg)", 19], 
   [7, "Tomatoes(1kg)", 22], 
   [8, "Capsicum(1kg)", 48],
   [9, "Ladies Finger(1kg)", 60]
]

Foodgrains_spices = [
  [0, "Wheat Flour(1kg)", 55], 
  [1, "Besan(1kg)", 89], 
  [2, "Basmati Rice(1kg)", 75],
  [3, "Toor Dal(1kg)", 125], 
  [4, "White Flour(1kg)", 100], 
  [5, "Sugar(1kg)", 48],    
  [6, "Ghee(1L)", 990], 
  [7, "Salt(1kg)", 18],
  [8, "Edible Oil(1L)", 183],
  [9, "Poha(1kg)", 60]
]

Dairy = [
  [0, "Toned Milk(1L)", 61], 
  [1, "Butter(1pc)", 45], 
  [2, "Paneer(100g)", 40],
  [3, "Dahi(100g)", 20], 
  [4, "Cheese Slices(1packet)", 70], 
  [5, "Fresh Cream(1L)", 200],
  [6, "Almond Milk(1L)", 275], 
  [7, "Condensed Milk(1can)", 128], 
  [8, "Shrikhand(500g cup)", 100],
  [9, "Vanilla Milkshake(1L)", 200]
]

Snacks_and_BrandedFoods = [
    [0, 'Cream Biscuits', 30],
    [1, 'Muesli', 375],
    [2, 'Honey', 185],
    [3, 'Tomato Ketchup', 189],
    [4, 'Mixed Fruit Jam', 65],
    [5, 'Potato Chips', 20],
    [6, 'Instant Noodles', 15],
    [7, 'Chocolate Bars', 10],
    [8, 'Vinegar', 210],
    [9, 'Nutella', 354]
]

Eggs_Meat_and_Fish = [
    [0, 'Egg(1 dozen)', 84],
    [1, 'Chicken(1 kg)', 250],
    [2, 'Mutton (1 kg)', 310],
    [3, 'King Fish (500 g)', 450],
    [4, 'White Pomfret (6 pcs)', 440],
    [5, 'Rohu Fish (1 kg)', 189],
    [6, 'Mackerel/Bangda (1 kg)', 200],
    [7, 'Hilsa Fish', 1500],
    [8, 'Beef (1 kg)', 455],
    [9, 'Pork (1 kg)', 480]
]

customer_basket = []     #list to store the items in the customers basket [[name,quantity,total price],[name,quantity,total price],..]
bill = 0      #this will hold the total amount before taxes and discounts


def basket(item_code_int, list):   # a function to create the customer basket as soon as he/she adds an item
    global bill
    global customer_basket
    print(list[item_code_int][1])       #print the item name selected by the customer then error handling is done
    try:
        quantity = int(input("Enter quantity:"))
        if quantity <= 0:
            print("Enter valid quantity.")
            return
        else:
            customer_basket.append([list[item_code_int][1], quantity, list[item_code_int][2] * quantity])  #creating customers basket
    except:
        print("INVALID\n")
        basket(item_code_int, list)      #returns back to this function again if error

def calculate_bill():    #function to calculate the bill
    global bill
    global customer_basket
    bill = 0
    for items in customer_basket:
        bill = bill + items[2]        #bill = bill + total price of that item


def look_at_basket():     #function to take a look at the basket and update it
    global customer_basket
    global bill
    k = 0
    choice = ''
    item_no = 0
    quantity = 0

    for items in customer_basket:    #prints the basket
        print("Item No.:", k, " Item Name:", items[0], "Quantity:", items[1], "Price:", items[2])
        k += 1
    k = 0
    # calculate bill function here
    calculate_bill()
    print("Total Price: ", bill)
    # updating quantity here along with error handling
    if bill == 0:
        return
    choice = input("Do you want to update quantities: Type yes or no:")
    if choice == 'yes':
        try:
            item_no = int(input(("Enter Item No")))
            quantity = int(input("Enter new quantity"))
            if quantity == 0:  #if entered quantity is zero, deletes that item from the basket
                customer_basket.pop(item_no)
            else:   #modifies the basket with the new quantity
                customer_basket[item_no][2] = (customer_basket[item_no][2] // customer_basket[item_no][1]) * quantity
                customer_basket[item_no][1] = quantity

            print("UPDATED BASKET: ")   #prints updated basket
            look_at_basket()            #returns
        except:
            print("INVALID, REDIRECTING BACK\n")
            look_at_basket()
    elif choice == 'no':
        return
    else:
        print("INVALID\n")         #returns when entered choice is invalid
        look_at_basket()

def customer(name):   #displaying all categories
    global GST
    global gst
    global bill
    item_code_int = 0
    print("**********************************************************")
    print("WELCOME TO OUR STORE,", name, ": PLEASE CHOOSE A CATEGORY")
    print("1.Fruits and Vegetables")
    print("2.Foodgrains and Spices")
    print("3.Dairy")
    print("4.Snacks")
    print("5.Eggs,Meat and Fish")
    print("Choose any of the above option OR")        #asks the user to make a choice
    print("PRESS 10 to calculate the bill.")
    print("PRESS 11 to take a look at the basket.\n")

    choice = input("Enter choice: ")
    # error handling here if invalid choice
    if choice == '1':
        try:
            while item_code_int != 10:
                for products in Fruits_vegetables:  # displaying all the items
                    print("Item Code:", products[0], "Item:", products[1], ",Price:", products[2])
                item_code_int = int(input("Enter item code: or 10 to go back: "))
                if item_code_int == 10: #if user enters 10 then takes them back
                    customer(name)
                    continue
                basket(item_code_int, Fruits_vegetables) #takes them to the basket function to enter quantity
        except:
            print("INVALID,REDIRECTING BACK\n")
            customer(name)
    elif choice == '2':     #similar to before
        try:
            while item_code_int != 10:
                for products in Foodgrains_spices:  # displaying all the items
                    print("Item Code:", products[0], "Item:", products[1], ",Price:", products[2])
                item_code_int = int(input("Enter item code: or 10 to go back"))
                if item_code_int == 10:
                    customer(name)
                    continue
                basket(item_code_int, Foodgrains_spices)
        except:
            print("INVALID,REDIRECTING BACK\n")
            customer(name)
    elif choice == '3':        #similar to before
        try:
            while item_code_int != 10:
                for products in Dairy:  # displaying all the items
                    print("Item Code:", products[0], "Item:", products[1], ",Price:", products[2])
                item_code_int = int(input("Enter item code: or 10 to go back"))
                if item_code_int == 10:
                    customer(name)
                    continue
                basket(item_code_int, Dairy)
        except:
            print("INVALID,REDIRECTING BACK\n")
            customer(name)
    elif choice == '4':         #similar to before
        try:
            while item_code_int != 10:
                for products in Snacks_and_BrandedFoods:  # displaying all the items
                    print("Item Code:", products[0], "Item:", products[1], ",Price:", products[2])
                item_code_int = int(input("Enter item code: or 10 to go back"))
                if item_code_int == 10:
                    customer(name)
                    continue
                basket(item_code_int, Snacks_and_BrandedFoods)
        except:
            print("INVALID,REDIRECTING BACK\n")
            customer(name)
    elif choice == '5':           #similar to before
        try:
            while item_code_int != 10:
                for products in Eggs_Meat_and_Fish:  # displaying all the items
                    print("Item Code:", products[0], "Item:", products[1], ",Price:", products[2])
                item_code_int = int(input("Enter item code: or 10 to go back"))
                if item_code_int == 10:
                    customer(name)
                    continue
                basket(item_code_int, Eggs_Meat_and_Fish)
        except:
            print("INVALID,REDIRECTING BACK\n")
            customer(name)
    elif choice == '10':
      calculate_bill()
      GST = (0.18)*bill
      gst = int(GST)
      new_bill = bill - discount(bill) + gst
      checkout(customer_basket, your_name, bill, new_bill, gst)
    elif choice == '11':
        look_at_basket()
        customer(name)
    else:
        print("INVALID, TRY AGAIN")
        customer(name)
'''TARIKA'S CODE ENDS'''

'''MANALI'S CODE STARTS'''
#Importing a module for inserting today's date in the bill
from datetime import date

#The following variable stores today's date
oneul = date.today()

#We will now create a function to apply discounts if applicable
def discount(b):
  if 500<= b <1000:
    #5% discount 
    disc = (0.05)*b
  elif 1000<= b < 2000:
    #10% discount
    disc = (0.1)*b
  elif 2000<= b < 5000:
    #15% discount
    disc = (0.15)*b
  elif b>= 5000:
    #20% discount
    disc = (0.2)*b
  else:
    disc = 0
  return int(disc)

#We'll use this module to print an image
import matplotlib.image as image
import matplotlib.pyplot as plt

#This function enables the customer to make the payment
def pay(new_bill):
  while True:
    try:
      paid = int(input("Enter the amount payable: "))
      if paid == new_bill:
        print("Transaction successful.")
        print("Thank you for shopping with us!")
        img = image.imread("dotpy_thanks.jpg")
        plt.imshow(img)
        break
    except:
      print("Transaction failed. Pay exactly the total printed on the bill.")

#The checkout function defined below generates a bill in a file 
def checkout(bag, name, bill, new_bill, gst):
  #We are attempting to make a beautiful bill, hence the fancy headers below
  header1 = "             THE GROCERY STORE             \n"
  header2 = "*******************************************\n"
  header3 = "                   BILL                    \n"
  header4 = "-------------------------------------------\n"
  string1 = header1 + header2 + header3 + header4

  #strings for lines to be printed after enlisting items bought
  #The width of the bill is a fixed number of characters
  string3 = "\n" + 37*(" ") + "______" 
  string4 = "\n" + (35 - len(str(bill)))*(" ") + "Total = " + str(bill)
  discount_line = "\n" + (32 - len(str(discount(bill))))*(" ") + "Discount = " + str(discount(bill))
  gst_line = "\n" + (37 - len(str(gst)))*(" ") + "GST = " + str(gst)
  string5 = "\n" + (29 - len(str(new_bill)))*(" ") + "Grand Total = " + str(new_bill)
  datestring = "\n" + str(oneul) + "\n"

  #We now open the empty text file bill.txt to write and read it
  file = open("dotpy_bill.txt", mode = 'w+')
  #We write the various strings in the file
  file.write(string1)
  file.write(name)
  file.write(datestring)

  #We iterate through the basket list
  #create a string for each item bought and write it in the file 
  for i in bag:
    '''For our bill to look neat and organised we need to 
    anage the spaces between the words and numbers'''
    space1 = 30 - len(i[0])
    space101 = 3 - len(str(i[1]))
    space2 = 6 - len(str(i[2]))
    string2 = "\n" + i[0] + space1*(" ") + space101*(" ") + str(i[1]) + 4*(" ") + space2*(" ") + str(i[2])
    file.write(string2)

  file.write(string3)
  file.write(string4)

  file.write(discount_line)
  file.write(gst_line)
  file.write(string5)

  #we close the file once we're done writing
  file.close()
  #we reopen it only to read this time
  file_created = open("dotpy_bill.txt", mode = 'r')
  output = file_created.read()
  #we print the contents of the file for the user to see
  print(output)

  #we now call the pay function defined earlier in this code
  pay(new_bill)

option = input("Type 1 to LOGIN, 2 to SIGNUP : ")
if option == "1":
  login(users)
elif option == "2":
  signup()
#elif choice == 123:
  #shopkeeper()
else:
  while option != "1" or choice != "2":
    option = input("Enter valid choice: ")
    if option == "1":
      login(users)
      break
    elif option == "2":
      signup()
      break

if start == 1:
  #Taking the name to be printed on the bill as input
  your_name = input("Enter your name: ")  
  customer(your_name)
  '''THE END'''